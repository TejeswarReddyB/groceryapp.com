import { Component, OnInit } from '@angular/core';
import { AuthenticateService } from 'src/app/authenticate.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private authService: AuthenticateService) { }

  ngOnInit(): void {
  }

 
    
    
  onSubmit(data:any){
    
    // this.authService.postLogin(data).subscribe( x =>{
    //   console.log(x.data)
    // })
  
  }
}
