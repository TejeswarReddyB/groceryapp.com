import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs'; 

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  constructor( private http :HttpClient) { }

  postRegister(data:any): Observable <any>{

   return this.http.post<any>('http://apolis-grocery.herokuapp.com/api/auth/register',data);
  }
  // postLogin(data:any): Observable <any>{

  //   return this.http.post<any>('http://apolis-grocery.herokuapp.com/api/auth/login',data);
  //  }
}
